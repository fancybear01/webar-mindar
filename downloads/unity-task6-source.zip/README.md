# Задание 6 — Unity WebXR, viewer-space

## Текущий статус

Подготовлены исходники проекта для Unity 6000.3.7f1, встроен настоящий пакет `com.de-panther.webxr` 0.25.0 и официальный шаблон WebXRFullView2020. Исходный upstream: https://github.com/De-Panther/unity-webxr-export, коммит `1f7a06c57867f300dabfa2bbbee85a6b03fa0005`. Лицензия пакета находится в его папке.

Попытка запуска редактора завершилась ошибкой `No valid Unity Editor license found` (см. `prepare.log`). Поэтому проект ещё НЕ скомпилирован: сцена и prefab будут созданы скриптом после успешного запуска Unity. WebGL-сборки пока нет; реальный размер и совместимость на телефоне не измерены.

## Что сделать в Unity Hub

1. Войти в свой Unity-аккаунт и активировать подходящую лицензию. Unity Personal используйте только если вам подходят её условия. В зависимости от версии Hub лицензия появляется после входа или добавляется через Settings → Licenses.
2. В Installs у Unity **6000.3.7f1** выбрать Add modules → **Web Build Support / WebGL Build Support** и установить модуль. Редактор уже установлен, но этот модуль отсутствовал.
3. Готовый официальный установщик модуля также скачан в `../tmp/UnitySetup-WebGL-6000.3.7f1.exe` (952377640 байт); цифровая подпись Unity проверена. Установка в Program Files может потребовать подтверждения Windows. Установщик не входит в проект и архив.
4. В Projects → Add project from disk выбрать эту папку.

## Быстрая сборка через терминал

Закройте этот проект в редакторе Unity, затем откройте PowerShell в его папке:

```powershell
powershell -ExecutionPolicy Bypass -File .\Build.ps1
```

Скрипт запустит установленный редактор, дождётся его завершения и проверит наличие `Build/WebGL/index.html` и `build-metrics.json`. Подробности пишутся в `build.log`.

Альтернативно в редакторе после импорта проекта: меню **WebAR → Prepare task 6 scene**, затем **WebAR → Build task 6 WebGL**. Подготовка пересоздаёт учебную сцену и prefab; ручные изменения в них предварительно сохраните отдельно.

## Что создаёт код

`Assets/Editor/BuildTask6.cs` создаёт сцену `Assets/Scenes/ViewerSpace.unity`: WebXRManager, camera rig/prefab `WebXRCameraSet`, пять камер для обычного/VR/AR-режимов, два настоящих компонента WebXRController, освещение и куб с PBR-материалом Standard.

В актуальном пакете компонент камеры называется **WebXRCamera**, а WebXRCameraSet — имя camera rig/prefab. Для Built-in Render Pipeline включён официальный режим `DisableXRDisplaySubsystem`, в XR Plug-in Management назначается WebXRLoader. Обязательное пространство AR — `viewer`.

`Assets/Scripts/ViewerSpaceCube.cs` выбирает активную камеру и держит куб на расстоянии 0,65 м перед ней. Это именно viewer-space: куб намеренно следует за телефоном. В заданиях 4–5, наоборот, объект остаётся на найденной поверхности.

Настройки сборки задаются скриптом: WebGL, compression Disabled, decompression fallback false, threadsSupport false, IL2CPP OptimizeSize, начальная память 128 МБ и максимум 512 МБ. Отключение сжатия упрощает статический хостинг, но увеличивает загрузку.

## Публикация и проверка

После успешной сборки нужно публиковать **всю** папку `Build/WebGL`, а не только HTML. Например, разместить её содержимое в `unity-viewer/` на существующем GitHub Pages и открыть по HTTPS. Локальный HTTP подходит только на самом компьютере через localhost; адрес HTTP вида 192.168... на телефоне не заменяет HTTPS. Для локального HTTPS нужен доверенный телефоном сертификат.

На Android откройте сборку в Chrome, дождитесь полной загрузки и нажмите AR в WebXR-шаблоне. Разрешите камеру. Проверьте куб в центре экрана и его следование при повороте и перемещении телефона. Для AR нужны совместимые устройство, WebXR и ARCore; наличие Chrome само по себе совместимость не гарантирует. Настольный предпросмотр не подтверждает мобильный AR.

После успешной сборки `build-metrics.json` содержит фактический размер по BuildReport. Дополнительно размер файлов на диске можно измерить:

```powershell
(Get-ChildItem .\Build\WebGL -Recurse -File | Measure-Object Length -Sum).Sum
```

В отчёте нужно отдельно записать модель телефона, Android, версию Chrome, время загрузки и результат AR. Сейчас все эти результаты имеют статус **не проверено**.
