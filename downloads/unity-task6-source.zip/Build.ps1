param(
    [string]$UnityEditor = 'C:\Program Files\Unity\Hub\Editor\6000.3.7f1\Editor\Unity.exe'
)
$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
if (-not (Test-Path -LiteralPath $UnityEditor)) { throw "Unity Editor not found: $UnityEditor" }
if (-not (Test-Path -LiteralPath (Join-Path (Split-Path $UnityEditor) 'Data\PlaybackEngines\WebGLSupport'))) {
    throw 'Install Web Build Support for Unity 6000.3.7f1 in Unity Hub first.'
}
$buildLog = Join-Path $project 'build.log'
$unityArgs = '-batchmode -quit -nographics -accept-apiupdate -buildTarget WebGL -projectPath "{0}" -executeMethod WebAR.Task6.Editor.BuildTask6.Build -logFile "{1}"' -f $project, $buildLog
$process = Start-Process -FilePath $UnityEditor -ArgumentList $unityArgs -WindowStyle Hidden -PassThru -Wait
if ($process.ExitCode -ne 0) { throw "Unity failed (exit $($process.ExitCode)). Read $buildLog" }
$html = Join-Path $project 'Build\WebGL\index.html'
$metrics = Join-Path $project 'Build\WebGL\build-metrics.json'
if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $metrics)) { throw "Build files are missing. Read $buildLog" }
Write-Host "WebGL build ready: $html"
Get-Content -LiteralPath $metrics
