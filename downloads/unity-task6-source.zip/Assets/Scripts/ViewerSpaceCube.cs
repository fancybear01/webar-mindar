using UnityEngine;
using WebXR;

namespace WebAR.Task6
{
    // Viewer-space: объект намеренно следует за камерой, в отличие от hit-test.
    public sealed class ViewerSpaceCube : MonoBehaviour
    {
        public Transform cameraSet;
        public Transform cube;
        public float distance = 0.65f;
        private Camera[] cameras;
        private WebXRState state = WebXRState.NORMAL;

        private void Awake() => cameras = cameraSet.GetComponentsInChildren<Camera>(true);
        private void OnEnable() => WebXRManager.OnXRChange += OnXRChange;
        private void OnDisable() => WebXRManager.OnXRChange -= OnXRChange;
        private void OnXRChange(WebXRState value, int views, Rect left, Rect right) => state = value;

        private void LateUpdate()
        {
            foreach (Camera view in cameras)
            {
                if (!view.isActiveAndEnabled) continue;
                if (cube.parent != view.transform) cube.SetParent(view.transform, false);
                cube.localPosition = new Vector3(0, 0, distance);
                cube.localRotation = Quaternion.Euler(15, Time.time * 24, 0);
                break;
            }
        }

        private void OnGUI()
        {
            GUIStyle style = new GUIStyle(GUI.skin.box) { fontSize = 18, alignment = TextAnchor.MiddleCenter, wordWrap = true };
            string message = state == WebXRState.AR
                ? "Viewer-space: куб находится перед камерой и следует за телефоном."
                : "Задание 6 — Unity WebXR. Нажмите AR внизу страницы. Куб появится в центре поля зрения.";
            GUI.Box(new Rect(12, 12, Mathf.Min(Screen.width - 24, 680), 68), message, style);
        }
    }
}
